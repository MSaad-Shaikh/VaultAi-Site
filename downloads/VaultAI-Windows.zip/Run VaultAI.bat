@echo off
title VaultAI - First Run Setup
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup and Run VaultAI.ps1"
if errorlevel 1 (
    echo.
    echo Setup did not finish. Read the message above, then press any key to close.
    pause >nul
    exit /b 1
)
start "VaultAI" "%~dp0VaultAI.exe"

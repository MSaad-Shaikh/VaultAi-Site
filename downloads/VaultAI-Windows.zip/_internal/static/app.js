// VaultAI Frontend — Redesigned Minimal Dark UI

document.addEventListener("DOMContentLoaded", () => {

  // ── Element References ─────────────────────────────────────────
  const railBtns = document.querySelectorAll(".rail-btn");
  const sidebarPanels = document.querySelectorAll(".sidebar-section-panel");
  const tabContents = document.querySelectorAll(".tab-content");
  const sidebarPanel = document.getElementById("sidebar-panel");
  const btnRailToggleSidebar = document.getElementById("btn-rail-toggle-sidebar");
  const btnToggleSidebar = document.getElementById("btn-toggle-sidebar");
  const btnCloseSidebarElements = document.querySelectorAll(".btn-close-sidebar");

  const railStatusDot = document.getElementById("rail-status-dot");
  const statusDot = document.getElementById("status-dot");
  const statusText = document.getElementById("status-text");
  const statusDetail = document.getElementById("status-detail");

  const statDocs = document.getElementById("stat-docs");
  const statPassages = document.getElementById("stat-passages");

  const chatList = document.getElementById("chat-list");
  const btnNewChat = document.getElementById("btn-new-chat");
  const messagesContainer = document.getElementById("messages-container");
  const chatInput = document.getElementById("chat-input");
  const btnSendChat = document.getElementById("btn-send-chat");
  const btnChatMic = document.getElementById("btn-chat-mic");
  const chatDocFilter = document.getElementById("chat-doc-filter");
  const inputDocPill = document.getElementById("input-doc-pill");
  const chatInputHint = document.getElementById("chat-input-hint");

  const fileUploader = document.getElementById("file-uploader");
  const btnChooseFile = document.getElementById("btn-choose-file");
  const btnLoadSamples = document.getElementById("btn-load-samples");
  const btnResetVault = document.getElementById("btn-reset-vault");

  const docCardsGrid = document.getElementById("doc-cards-grid");
  const sidebarDocList = document.getElementById("sidebar-doc-list");

  const actionTypeSelect = document.getElementById("action-type-select");
  const groupDocA = document.getElementById("group-doc-a");
  const groupDocB = document.getElementById("group-doc-b");
  const actionDocA = document.getElementById("action-doc-a");
  const actionDocB = document.getElementById("action-doc-b");
  const btnRunAction = document.getElementById("btn-run-action");
  const actionResultBox = document.getElementById("action-result-box");
  const actionOutputText = document.getElementById("action-output-text");
  const actionCitationsBox = document.getElementById("action-citations-box");

  const settingEndpoint = document.getElementById("setting-endpoint");
  const settingChatModel = document.getElementById("setting-chat-model");
  const settingEmbedModel = document.getElementById("setting-embed-model");
  const btnSaveSettings = document.getElementById("btn-save-settings");

  const pdfModal = document.getElementById("pdf-modal");
  const btnCloseModal = document.getElementById("btn-close-modal");
  const modalImg = document.getElementById("modal-img");
  const modalTitle = document.getElementById("modal-title");

  // ── Authentication & User Elements ────────────────────────────
  const authModal = document.getElementById("auth-modal");
  const tabBtnLogin = document.getElementById("tab-btn-login");
  const tabBtnRegister = document.getElementById("tab-btn-register");
  const formLogin = document.getElementById("form-login");
  const formRegister = document.getElementById("form-register");
  const authAlert = document.getElementById("auth-alert");
  const loginUsername = document.getElementById("login-username");
  const loginPassword = document.getElementById("login-password");
  const btnSubmitLogin = document.getElementById("btn-submit-login");
  const regName = document.getElementById("reg-name");
  const regUsername = document.getElementById("reg-username");
  const regEmail = document.getElementById("reg-email");
  const regPassword = document.getElementById("reg-password");
  const btnSubmitRegister = document.getElementById("btn-submit-register");

  const railUserAvatar = document.getElementById("rail-user-avatar");
  const btnRailUser = document.getElementById("btn-rail-user");
  const userAvatarSm = document.getElementById("user-avatar-sm");
  const userNameDisplay = document.getElementById("user-name-display");
  const userRoleDisplay = document.getElementById("user-role-display");
  const btnUserLogout = document.getElementById("btn-user-logout");

  const accValDisplay = document.getElementById("acc-val-display");
  const accValUsername = document.getElementById("acc-val-username");
  const accValEmail = document.getElementById("acc-val-email");
  const accValCreated = document.getElementById("acc-val-created");
  const accValLastLogin = document.getElementById("acc-val-last-login");
  const btnSettingsLogout = document.getElementById("btn-settings-logout");
  const btnSettingsSwitch = document.getElementById("btn-settings-switch");
  const accCardSub = document.getElementById("acc-card-sub");
  const accStatusTag = document.getElementById("acc-status-tag");

  let currentUser = null;
  let activeChatId = null;
  let currentActiveChat = null;
  let allLoadedDocuments = {};

  const chatCurrentTitle = document.getElementById("chat-current-title");
  const btnRenameActiveChat = document.getElementById("btn-rename-active-chat");
  const btnExportChat = document.getElementById("btn-export-chat");
  const btnClearChat = document.getElementById("btn-clear-chat");
  const repoSearchInput = document.getElementById("repo-search-input");
  const btnChatAttach = document.getElementById("btn-chat-attach");
  const chatFileInput = document.getElementById("chat-file-input");
  const chatAttachmentPreviewStrip = document.getElementById("chat-attachment-preview-strip");
  const chatDropzoneOverlay = document.getElementById("chat-dropzone-overlay");
  const chatWrap = document.querySelector(".chat-wrap");
  let stagedAttachments = [];

  // ── Universal Document Viewer DOM Elements ────────────────────
  const docViewerIcon = document.getElementById("doc-viewer-icon");
  const docViewerMeta = document.getElementById("doc-viewer-meta");
  const docViewModeGroup = document.getElementById("doc-view-mode-group");
  const btnViewScan = document.getElementById("btn-view-scan");
  const btnViewText = document.getElementById("btn-view-text");
  const docPageNav = document.getElementById("doc-page-nav");
  const btnPrevPage = document.getElementById("btn-prev-page");
  const btnNextPage = document.getElementById("btn-next-page");
  const docPageIndicator = document.getElementById("doc-page-indicator");
  const btnDownloadDoc = document.getElementById("btn-download-doc");
  const btnCopyDocText = document.getElementById("btn-copy-doc-text");
  const docViewerLoader = document.getElementById("doc-viewer-loader");
  const docVisualContainer = document.getElementById("doc-visual-container");
  const docTextContainer = document.getElementById("doc-text-container");
  const docTextContent = document.getElementById("doc-text-content");

  // ── Sidebar Collapse / Expand Functionality ─────────────────
  const SIDEBAR_COLLAPSED_KEY = "vault_sidebar_collapsed";

  function setSidebarCollapsed(collapsed, animate = true) {
    if (!sidebarPanel) return;

    if (!animate) {
      sidebarPanel.style.transition = "none";
    }

    if (collapsed) {
      sidebarPanel.classList.add("collapsed");
      if (btnRailToggleSidebar) {
        btnRailToggleSidebar.classList.add("collapsed");
        btnRailToggleSidebar.title = "Expand sidebar (Ctrl+\\)";
        btnRailToggleSidebar.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="3" x2="9" y2="21"/>
            <path d="m11 9 3 3-3 3"/>
          </svg>
        `;
      }
      if (btnToggleSidebar) {
        btnToggleSidebar.classList.add("collapsed");
        btnToggleSidebar.title = "Expand sidebar (Ctrl+\\)";
        btnToggleSidebar.innerHTML = `
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="3" x2="9" y2="21"/>
            <path d="m11 9 3 3-3 3"/>
          </svg>
        `;
      }
    } else {
      sidebarPanel.classList.remove("collapsed");
      if (btnRailToggleSidebar) {
        btnRailToggleSidebar.classList.remove("collapsed");
        btnRailToggleSidebar.title = "Collapse sidebar (Ctrl+\\)";
        btnRailToggleSidebar.innerHTML = `
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="3" x2="9" y2="21"/>
            <path d="m14 9-3 3 3 3"/>
          </svg>
        `;
      }
      if (btnToggleSidebar) {
        btnToggleSidebar.classList.remove("collapsed");
        btnToggleSidebar.title = "Collapse sidebar (Ctrl+\\)";
        btnToggleSidebar.innerHTML = `
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <rect x="3" y="3" width="18" height="18" rx="2"/>
            <line x1="9" y1="3" x2="9" y2="21"/>
            <path d="m14 9-3 3 3 3"/>
          </svg>
        `;
      }
    }

    if (!animate) {
      void sidebarPanel.offsetHeight; // force reflow
      sidebarPanel.style.transition = "";
    }

    try {
      localStorage.setItem(SIDEBAR_COLLAPSED_KEY, collapsed ? "true" : "false");
    } catch (_) {}
  }

  function toggleSidebar() {
    const isCollapsed = sidebarPanel && sidebarPanel.classList.contains("collapsed");
    setSidebarCollapsed(!isCollapsed);
  }

  // Restore sidebar state from previous session
  try {
    if (localStorage.getItem(SIDEBAR_COLLAPSED_KEY) === "true") {
      setSidebarCollapsed(true, false);
    }
  } catch (_) {}

  if (btnRailToggleSidebar) {
    btnRailToggleSidebar.addEventListener("click", () => toggleSidebar());
  }

  if (btnToggleSidebar) {
    btnToggleSidebar.addEventListener("click", () => toggleSidebar());
  }

  btnCloseSidebarElements.forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      setSidebarCollapsed(true);
    });
  });

  // Keyboard shortcut Ctrl+\ / Cmd+\
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "\\") {
      e.preventDefault();
      toggleSidebar();
    }
  });

  // ── Navigation: Rail + Sidebar + Main Pane sync ───────────────
  const tabSidebarMap = {
    "tab-chat":     "sidebar-chat",
    "tab-actions":  "sidebar-actions",
    "tab-docs":     "sidebar-docs",
    "tab-settings": "sidebar-settings",
  };

  function navigateTo(tabId) {
    railBtns.forEach(b => b.classList.remove("active"));
    sidebarPanels.forEach(p => p.classList.remove("active"));
    tabContents.forEach(c => c.classList.remove("active"));

    const railBtn = document.querySelector(`.rail-btn[data-tab="${tabId}"]`);
    if (railBtn) railBtn.classList.add("active");

    const panelId = tabSidebarMap[tabId];
    if (panelId) {
      const panel = document.getElementById(panelId);
      if (panel) panel.classList.add("active");
    }

    const section = document.getElementById(tabId);
    if (section) section.classList.add("active");

    if (tabId === "tab-actions") populateActionDocSelectors();
    if (tabId === "tab-docs") loadDocumentsList();
    if (tabId === "tab-settings") refreshStatus();
  }

  railBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const tabId = btn.getAttribute("data-tab");
      if (!tabId) return;

      const isCurrentActive = btn.classList.contains("active");
      const isCollapsed = sidebarPanel && sidebarPanel.classList.contains("collapsed");

      if (isCurrentActive && !isCollapsed) {
        setSidebarCollapsed(true);
      } else {
        if (isCollapsed) {
          setSidebarCollapsed(false);
        }
        navigateTo(tabId);
      }
    });
  });

  // ── Status ────────────────────────────────────────────────────
  async function refreshStatus() {
    try {
      const res = await fetch("/api/status");
      const data = await res.json();

      const online = data.backend && data.backend.online;
      if (online) {
        statusDot.className = "status-dot dot-green";
        statusText.textContent = `Connected (${data.backend.latency_ms}ms)`;
        if (statusDetail) statusDetail.textContent = `Endpoint: ${data.backend.endpoint}`;
        railStatusDot.classList.add("online");
      } else {
        statusDot.className = "status-dot dot-amber";
        statusText.textContent = "Ollama Offline";
        if (statusDetail) statusDetail.textContent = "Run: ollama serve";
        railStatusDot.classList.remove("online");
      }

      if (statDocs) statDocs.textContent = data.stats.doc_count;
      if (statPassages) statPassages.textContent = data.stats.chunk_count;

      if (data.config) {
        settingEndpoint.value = data.config.endpoint;
        settingChatModel.value = data.config.chat_model;
        settingEmbedModel.value = data.config.embed_model;
      }
    } catch {
      statusDot.className = "status-dot dot-amber";
      statusText.textContent = "Server Error";
      railStatusDot.classList.remove("online");
    }
  }

  // ── Conversations ─────────────────────────────────────────────
  function fmtTiming(str) {
    if (!str) return "";
    // "2026-10-19 13:26" → "Oct 19 · 13:26"
    try {
      const [d, t] = str.split(" ");
      const [y, mo, dy] = d.split("-");
      const mon = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][parseInt(mo)-1];
      return `${mon} ${parseInt(dy)} · ${t}`;
    } catch { return str; }
  }

  async function loadConversations() {
    try {
      const res = await fetch("/api/conversations");
      const data = await res.json();
      chatList.innerHTML = "";

      const active = data.active_chat;
      activeChatId = active ? active.id : null;
      currentActiveChat = active;

      if (chatCurrentTitle) {
        chatCurrentTitle.textContent = (active && active.title) ? active.title : "General Research";
      }

      if (active) {
        renderMessages(active.messages || []);
      }

      if (!data.chats || data.chats.length === 0) {
        chatList.innerHTML = "<div style='padding: 12px 8px; font-size:0.75rem; color: var(--text-3);'>No conversations yet</div>";
        return;
      }

      data.chats.forEach(chat => {
        const item = document.createElement("div");
        item.className = `chat-item ${chat.id === activeChatId ? "active" : ""}`;
        const msgCount = (chat.messages && chat.messages.length) || 0;
        const timing = fmtTiming(chat.updated_at || chat.created_at);

        item.innerHTML = `
          <div class="chat-item-content">
            <div class="chat-item-title">${escHtml(chat.title)}</div>
            <div class="chat-item-meta"><span>${timing}</span><span>·</span><span>${msgCount} msg${msgCount !== 1 ? 's' : ''}</span></div>
          </div>
          <div class="chat-item-actions">
            <button class="icon-btn btn-rename" title="Rename">✏</button>
            <button class="icon-btn btn-del" title="Delete">✕</button>
          </div>
        `;

        item.addEventListener("click", e => {
          if (e.target.closest(".btn-rename") || e.target.closest(".btn-del")) return;
          setActiveChat(chat.id);
        });

        item.querySelector(".btn-rename").addEventListener("click", async e => {
          e.stopPropagation();
          const t = prompt("Rename conversation:", chat.title);
          if (t && t.trim()) {
            await fetch("/api/conversations/rename", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id: chat.id, title: t.trim() }),
            });
            loadConversations();
          }
        });

        item.querySelector(".btn-del").addEventListener("click", async e => {
          e.stopPropagation();
          if (confirm(`Delete "${chat.title}"?`)) {
            await fetch("/api/conversations/delete", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id: chat.id }),
            });
            loadConversations();
          }
        });

        chatList.appendChild(item);
      });
    } catch(e) { console.error(e); }
  }

  async function setActiveChat(id) {
    await fetch("/api/conversations/active", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });
    loadConversations();
  }

  async function startNewConversation() {
    const res = await fetch("/api/conversations/new", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: "{}",
    });
    const data = await res.json();
    if (data.chat) activeChatId = data.chat.id;
    await loadConversations();
    chatInput.value = "";
    chatInput.focus();
    navigateTo("tab-chat");
  }

  btnNewChat.addEventListener("click", startNewConversation);

  // Active Chat Header Actions
  if (btnRenameActiveChat) {
    btnRenameActiveChat.addEventListener("click", async () => {
      if (!currentActiveChat) return;
      const t = prompt("Rename current conversation:", currentActiveChat.title);
      if (t && t.trim()) {
        await fetch("/api/conversations/rename", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: currentActiveChat.id, title: t.trim() }),
        });
        loadConversations();
      }
    });
  }

  if (btnExportChat) {
    btnExportChat.addEventListener("click", () => {
      exportActiveChatMarkdown(currentActiveChat);
    });
  }

  if (btnClearChat) {
    btnClearChat.addEventListener("click", async () => {
      if (confirm("Clear all messages in the active conversation?")) {
        await fetch("/api/conversations/clear_active", { method: "POST" });
        loadConversations();
      }
    });
  }

  // ── Markdown Parser ───────────────────────────────────────────
  function formatMarkdown(text) {
    if (!text) return "";
    let safe = escHtml(text);

    // Code blocks: ```lang \n code \n ```
    safe = safe.replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (match, lang, code) => {
      const language = lang.trim() || "CODE";
      return `
        <div class="code-block-box">
          <div class="code-block-header">
            <span>${language}</span>
            <button class="code-copy-btn" onclick="copyCodeSnippet(this)">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              <span>Copy</span>
            </button>
          </div>
          <pre><code>${code.trim()}</code></pre>
        </div>`;
    });

    // Inline code: `code`
    safe = safe.replace(/`([^`\n]+)`/g, '<code class="inline-code">$1</code>');

    // Bold: **text**
    safe = safe.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Italic: *text*
    safe = safe.replace(/\*([^*\n]+)\*/g, '<em>$1</em>');

    // Lists
    safe = safe.replace(/(?:^|\n)[ \t]*[-*][ \t]+([^\n]+)/g, '\n<li>$1</li>');
    safe = safe.replace(/(<li>.*?<\/li>)+/gs, '<ul>$&</ul>');

    // Paragraphs
    const paras = safe.split(/\n{2,}/).map(p => {
      p = p.trim();
      if (!p) return "";
      if (p.startsWith("<div") || p.startsWith("<ul") || p.startsWith("<ol") || p.startsWith("<table")) {
        return p;
      }
      return `<p>${p.replace(/\n/g, "<br>")}</p>`;
    }).join("");

    return paras || safe;
  }

  // Copy helper
  window.copyCodeSnippet = function(btn) {
    const pre = btn.closest(".code-block-box").querySelector("code");
    if (!pre) return;
    navigator.clipboard.writeText(pre.textContent).then(() => {
      const span = btn.querySelector("span");
      span.textContent = "Copied ✓";
      setTimeout(() => { span.textContent = "Copy"; }, 1500);
    });
  };

  function copyTextToClipboard(text, btn) {
    navigator.clipboard.writeText(text).then(() => {
      const span = btn.querySelector("span");
      if (span) {
        const orig = span.textContent;
        span.textContent = "Copied ✓";
        setTimeout(() => { span.textContent = orig; }, 1500);
      }
    });
  }

  // Text-To-Speech (Web Speech API)
  function speakText(text, btn) {
    if (!("speechSynthesis" in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      document.querySelectorAll(".btn-speak-msg").forEach(b => {
        b.classList.remove("active-speaking");
        const s = b.querySelector("span");
        if (s) s.textContent = "Read Aloud";
      });
      if (btn && btn.classList.contains("active-speaking")) return;
    }
    const cleanText = text.replace(/\[Source \d+\]/g, "").trim();
    const u = new SpeechSynthesisUtterance(cleanText);
    u.rate = 1.0;
    if (btn) {
      btn.classList.add("active-speaking");
      const s = btn.querySelector("span");
      if (s) s.textContent = "Stop";
    }
    u.onend = () => {
      if (btn) {
        btn.classList.remove("active-speaking");
        const s = btn.querySelector("span");
        if (s) s.textContent = "Read Aloud";
      }
    };
    u.onerror = () => {
      if (btn) {
        btn.classList.remove("active-speaking");
        const s = btn.querySelector("span");
        if (s) s.textContent = "Read Aloud";
      }
    };
    window.speechSynthesis.speak(u);
  }

  // ── Voice-To-Text / Speech Recognition (Web Speech API) ──────
  let speechRecognizer = null;
  let isListening = false;
  let shouldKeepListening = false;
  let baseTranscript = "";
  let restartTimeout = null;
  let micMediaStream = null;

  async function requestMicPermission() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        micMediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        return true;
      } catch (err) {
        console.warn("getUserMedia error:", err);
        return false;
      }
    }
    return true;
  }

  function releaseMicStream() {
    if (micMediaStream) {
      try {
        micMediaStream.getTracks().forEach(t => t.stop());
      } catch (e) {}
      micMediaStream = null;
    }
  }

  function initVoiceToText() {
    if (!btnChatMic) return;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      btnChatMic.title = "Voice dictation not supported in this browser (use Chrome/Edge/Safari)";
      btnChatMic.addEventListener("click", () => {
        alert("Voice-to-text is not supported in this browser. Please use Google Chrome, Microsoft Edge, or Safari.");
      });
      return;
    }

    try {
      speechRecognizer = new SpeechRecognition();
      speechRecognizer.continuous = true;
      speechRecognizer.interimResults = true;
      speechRecognizer.lang = navigator.language || "en-US";
      speechRecognizer.maxAlternatives = 1;

      speechRecognizer.onstart = () => {
        isListening = true;
        btnChatMic.classList.add("listening");
        btnChatMic.title = "Listening… Click to stop dictation";
        baseTranscript = chatInput.value ? (chatInput.value.trim() + " ") : "";
        chatInput.placeholder = "🎙️ Listening… Speak into your microphone";
      };

      speechRecognizer.onresult = (event) => {
        let interim = "";
        let final = "";
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        if (final) {
          baseTranscript += final + " ";
        }
        chatInput.value = baseTranscript + interim;
        chatInput.focus();
      };

      speechRecognizer.onerror = (event) => {
        console.warn("Speech recognition error:", event.error);
        if (event.error === "no-speech") {
          // Chrome fires "no-speech" after 1-2 seconds of silence. Keep alive!
          return;
        }
        if (event.error === "network") {
          alert("Speech recognition network error: Chrome and Edge require an active internet connection to transcribe audio using the browser engine. (In Brave browser: go to Settings > Privacy and enable 'Google Speech Services').");
          stopVoiceToText();
          return;
        }
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          alert("Microphone access was blocked. Please click the permissions icon in your browser address bar and allow Microphone access for this site.");
          stopVoiceToText();
          return;
        }
        if (event.error === "audio-capture") {
          alert("No microphone found or microphone is in use by another application. Please check your audio input devices.");
          stopVoiceToText();
          return;
        }
        if (event.error === "aborted") {
          return;
        }
      };

      speechRecognizer.onend = () => {
        // If user has not clicked stop, auto-restart to prevent Chrome's 2-second silence cutoff
        if (shouldKeepListening) {
          clearTimeout(restartTimeout);
          restartTimeout = setTimeout(() => {
            if (shouldKeepListening) {
              try {
                speechRecognizer.start();
              } catch (e) {
                console.warn("Restart voice recognition:", e);
              }
            }
          }, 150);
        } else {
          stopVoiceToText();
        }
      };

      btnChatMic.addEventListener("click", async () => {
        if (shouldKeepListening) {
          stopVoiceToText();
        } else {
          shouldKeepListening = true;
          const granted = await requestMicPermission();
          if (!granted) {
            alert("Microphone permission was not granted. Please allow microphone access to use voice dictation.");
            shouldKeepListening = false;
            stopVoiceToText();
            return;
          }

          try {
            speechRecognizer.start();
          } catch (err) {
            if (err.name !== "InvalidStateError") {
              console.error("Failed to start speech recognition:", err);
              stopVoiceToText();
            }
          }
        }
      });
    } catch (e) {
      console.error("Speech recognition initialization failed:", e);
    }
  }

  function stopVoiceToText() {
    shouldKeepListening = false;
    clearTimeout(restartTimeout);
    if (speechRecognizer) {
      try { speechRecognizer.stop(); } catch (e) {}
    }
    releaseMicStream();
    isListening = false;
    if (btnChatMic) {
      btnChatMic.classList.remove("listening");
      btnChatMic.title = "Voice to text (dictate)";
    }
    if (chatInput) {
      chatInput.placeholder = "Ask a question, or attach images & files…";
    }
  }

  // Export to Markdown Report
  function exportActiveChatMarkdown(chat) {
    if (!chat || !chat.messages || chat.messages.length === 0) {
      alert("No messages to export in this conversation.");
      return;
    }
    const title = chat.title || "Research Conversation";
    let md = `# VaultAI Intelligence Report: ${title}\n`;
    md += `*Generated: ${new Date().toLocaleString()} · 100% Offline Local Processing*\n\n---\n\n`;

    chat.messages.forEach(m => {
      const roleName = m.role === "user" ? "### 👤 User Query" : "### 🤖 VaultAI Analysis";
      md += `${roleName}\n`;
      if (m.doc_filter) md += `*Scoped Document Filter: ${m.doc_filter}*\n\n`;
      md += `${m.content}\n\n`;

      if (m.citations && m.citations.length > 0) {
        md += `#### 📚 Document Citations:\n`;
        m.citations.forEach(c => {
          md += `- **${c.source_tag}**: \`${c.doc_name}\` (${c.page_label}) — *Match: ${c.score}%*\n`;
          md += `  > ${c.excerpt.replace(/\n/g, " ")}\n`;
        });
        md += `\n`;
      }
      md += `---\n\n`;
    });

    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `VaultAI_${title.replace(/[^a-zA-Z0-9_-]/g, "_")}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // ── Message Rendering ─────────────────────────────────────────
  function renderMessages(messages) {
    messagesContainer.innerHTML = "";
    if (!messages || messages.length === 0) {
      messagesContainer.innerHTML = `
        <div class="empty-hero">
          <!-- Suggested Prompt Starters -->
          <div class="prompt-starters-section minimal-starters">
            <div class="prompt-starters-pills">
              <button type="button" class="prompt-card prompt-pill" data-prompt="Summarize the core objectives, key takeaways, and conclusions across the indexed documents.">
                <span class="prompt-card-icon">📋</span>
                <span class="prompt-card-title">Executive Summary</span>
              </button>

              <button type="button" class="prompt-card prompt-pill" data-prompt="Identify any critical compliance risks, legal obligations, and liability clauses stated in the documents.">
                <span class="prompt-card-icon">⚖️</span>
                <span class="prompt-card-title">Risk & Compliance</span>
              </button>

              <button type="button" class="prompt-card prompt-pill" data-prompt="Extract all major numerical metrics, financial figures, milestones, and project deadlines.">
                <span class="prompt-card-icon">📊</span>
                <span class="prompt-card-title">Metrics & Timelines</span>
              </button>

              <button type="button" class="prompt-card prompt-pill" data-prompt="What actionable recommendations or next steps are outlined in the documentation?">
                <span class="prompt-card-icon">💡</span>
                <span class="prompt-card-title">Strategic Actions</span>
              </button>
            </div>
          </div>
        </div>`;

      // Attach click handlers to prompt cards
      messagesContainer.querySelectorAll(".prompt-card").forEach(card => {
        card.addEventListener("click", () => {
          const prompt = card.getAttribute("data-prompt");
          if (prompt) {
            chatInput.value = prompt;
            sendMessage();
          }
        });
      });

      return;
    }

    messages.forEach(msg => {
      const div = document.createElement("div");
      div.className = `message ${msg.role}`;
      const avatarIcon = msg.role === "user" ? "U" : "V";

      let citHtml = "";
      if (msg.citations && msg.citations.length > 0) {
        citHtml = `
          <div class="citations-box">
            <div class="citations-label">Sources (${msg.citations.length})</div>
            ${msg.citations.map(c => {
              const score = typeof c.score === "number" ? c.score : 0;
              const isVerified = score >= 80;
              const badgeClass = isVerified ? "badge-verified" : "badge-review";
              const badgeLabel = isVerified ? `Verified • ${score}% Match` : `Needs Review • ${score}% Match`;
              const tierClass = isVerified ? "verified" : "review";
              const excerptSnippet = (c.excerpt || "").substring(0, 200);
              return `
              <div class="citation-card ${tierClass}">
                <div class="citation-header">
                  <span>${c.source_tag} — ${escHtml(c.doc_name)} · ${escHtml(c.page_label)}</span>
                  <span class="citation-score ${badgeClass}">${badgeLabel}</span>
                </div>
                <div class="citation-excerpt">${escHtml(excerptSnippet)}…</div>
                ${c.source_type === "PDF" ? `<button class="preview-btn" onclick="openPdfPreview('${encodeURIComponent(c.doc_name)}', ${c.page_num})">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                  View Page ${c.page_num}
                </button>` : ""}
              </div>`;
            }).join("")}
          </div>`;
      }

      let userScopeHtml = "";
      if (msg.role === "user" && msg.doc_filter) {
        userScopeHtml = `<div><span class="msg-scope-badge"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> ${escHtml(msg.doc_filter)}</span></div>`;
      }

      let attachmentsHtml = "";
      if (msg.attachments && msg.attachments.length > 0) {
        attachmentsHtml = `<div class="msg-attachments-container">` +
          msg.attachments.map(att => {
            const isImg = att.isImage || /\.(png|jpe?g|webp|svg|bmp)$/i.test(att.filename);
            if (isImg) {
              return `<img class="msg-img-attachment" src="/api/documents/preview?doc_name=${encodeURIComponent(att.filename)}" onclick="openPdfPreview('${encodeURIComponent(att.filename)}', 1)" title="${escHtml(att.filename)}" alt="${escHtml(att.filename)}">`;
            } else {
              return `<div class="msg-file-attachment">📄 ${escHtml(att.filename)}</div>`;
            }
          }).join("") +
          `</div>`;
      }

      let contentHtml = msg.role === "assistant"
        ? `<div class="message-body">${formatMarkdown(msg.content)}</div>`
        : `${attachmentsHtml}${userScopeHtml}${escHtml(msg.content)}`;

      let actionStripHtml = "";
      if (msg.role === "assistant") {
        actionStripHtml = `
          <div class="msg-action-strip">
            <button class="msg-action-btn btn-copy-msg" title="Copy response to clipboard">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
              <span>Copy</span>
            </button>
            <button class="msg-action-btn btn-speak-msg" title="Read response aloud">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
              <span>Read Aloud</span>
            </button>
          </div>`;
      }

      div.innerHTML = `
        <div class="msg-avatar" style="font-size:0.72rem; font-weight:700;">${avatarIcon}</div>
        <div class="msg-bubble">${contentHtml}${citHtml}${actionStripHtml}</div>`;

      if (msg.role === "assistant") {
        const copyBtn = div.querySelector(".btn-copy-msg");
        if (copyBtn) {
          copyBtn.addEventListener("click", () => copyTextToClipboard(msg.content, copyBtn));
        }
        const speakBtn = div.querySelector(".btn-speak-msg");
        if (speakBtn) {
          speakBtn.addEventListener("click", () => speakText(msg.content, speakBtn));
        }
      }

      messagesContainer.appendChild(div);
    });
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }

  // ── File & Image Attachment Staging ───────────────────────────
  function renderStagedAttachments() {
    if (!chatAttachmentPreviewStrip) return;
    if (stagedAttachments.length === 0) {
      chatAttachmentPreviewStrip.style.display = "none";
      chatAttachmentPreviewStrip.innerHTML = "";
      return;
    }
    chatAttachmentPreviewStrip.style.display = "flex";
    chatAttachmentPreviewStrip.innerHTML = stagedAttachments.map((item, idx) => {
      const thumb = item.isImage && item.dataUrl
        ? `<img class="attachment-thumb" src="${item.dataUrl}" alt="thumb">`
        : `<span class="attachment-pill-icon">📄</span>`;
      return `
        <div class="attachment-pill">
          ${thumb}
          <span class="attachment-pill-name" title="${escHtml(item.name)}">${escHtml(item.name)}</span>
          <button type="button" class="attachment-remove-btn" onclick="removeStagedAttachment(${idx})">✕</button>
        </div>`;
    }).join("");
  }

  window.removeStagedAttachment = function(idx) {
    stagedAttachments.splice(idx, 1);
    renderStagedAttachments();
  };

  function stageFiles(files) {
    if (!files || !files.length) return;
    Array.from(files).forEach(f => {
      const isImg = f.type.startsWith("image/") || /\.(png|jpe?g|webp|svg|bmp)$/i.test(f.name);
      const item = {
        file: f,
        name: f.name,
        size: f.size,
        type: f.type,
        isImage: isImg,
        dataUrl: "",
      };
      if (isImg) {
        const reader = new FileReader();
        reader.onload = e => {
          item.dataUrl = e.target.result;
          renderStagedAttachments();
        };
        reader.readAsDataURL(f);
      }
      stagedAttachments.push(item);
    });
    renderStagedAttachments();
  }

  if (btnChatAttach && chatFileInput) {
    btnChatAttach.addEventListener("click", () => chatFileInput.click());
    chatFileInput.addEventListener("change", () => {
      stageFiles(chatFileInput.files);
      chatFileInput.value = "";
    });
  }

  // Drag and Drop on chat view
  if (chatWrap && chatDropzoneOverlay) {
    let dragCounter = 0;
    chatWrap.addEventListener("dragenter", e => {
      e.preventDefault();
      dragCounter++;
      chatDropzoneOverlay.style.display = "flex";
    });
    chatWrap.addEventListener("dragover", e => {
      e.preventDefault();
    });
    chatWrap.addEventListener("dragleave", e => {
      e.preventDefault();
      dragCounter--;
      if (dragCounter <= 0) {
        dragCounter = 0;
        chatDropzoneOverlay.style.display = "none";
      }
    });
    chatWrap.addEventListener("drop", e => {
      e.preventDefault();
      dragCounter = 0;
      chatDropzoneOverlay.style.display = "none";
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) {
        stageFiles(e.dataTransfer.files);
      }
    });
  }

  // ── Send Message ──────────────────────────────────────────────
  async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text && stagedAttachments.length === 0) return;
    if (isListening) {
      stopVoiceToText();
    }
    const docFilter = chatDocFilter ? chatDocFilter.value : "";
    chatInput.value = "";
    btnSendChat.disabled = true;

    // Snapshot staged attachments
    const currentAttachments = [...stagedAttachments];
    stagedAttachments = [];
    renderStagedAttachments();

    // If attachments exist, upload them to vault
    let attachedMeta = [];
    if (currentAttachments.length > 0) {
      const uploadForm = new FormData();
      currentAttachments.forEach(att => uploadForm.append("files", att.file));
      try {
        await fetch("/api/documents/upload", { method: "POST", body: uploadForm });
        attachedMeta = currentAttachments.map(att => ({
          filename: att.name,
          isImage: att.isImage,
          type: att.isImage ? "IMAGE" : "FILE",
        }));
      } catch (err) {
        console.error("Failed to upload attachments:", err);
      }
    }

    const userScopeHtml = docFilter
      ? `<div><span class="msg-scope-badge"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> ${escHtml(docFilter)}</span></div>`
      : "";

    let attachmentsHtml = "";
    if (currentAttachments.length > 0) {
      attachmentsHtml = `<div class="msg-attachments-container">` +
        currentAttachments.map(att => {
          if (att.isImage && att.dataUrl) {
            return `<img class="msg-img-attachment" src="${att.dataUrl}" alt="${escHtml(att.name)}">`;
          } else {
            return `<div class="msg-file-attachment">📄 ${escHtml(att.name)}</div>`;
          }
        }).join("") +
        `</div>`;
    }

    const userDiv = document.createElement("div");
    userDiv.className = "message user";
    userDiv.innerHTML = `<div class="msg-avatar" style="font-size:0.72rem; font-weight:700;">U</div><div class="msg-bubble">${attachmentsHtml}${userScopeHtml}${escHtml(text)}</div>`;
    messagesContainer.appendChild(userDiv);

    const botDiv = document.createElement("div");
    botDiv.className = "message assistant";
    botDiv.innerHTML = `<div class="msg-avatar" style="font-size:0.72rem; font-weight:700;">V</div><div class="msg-bubble" style="color:var(--text-3); font-style:italic;">Retrieving relevant passages…</div>`;
    messagesContainer.appendChild(botDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    try {
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, doc_filter: docFilter, attachments: attachedMeta }),
      });
      await loadConversations();
      refreshStatus();
      loadDocumentsList();
    } catch {
      botDiv.querySelector(".msg-bubble").textContent = "Error — could not reach server.";
    } finally {
      btnSendChat.disabled = false;
      chatInput.focus();
    }
  }

  if (chatDocFilter) {
    chatDocFilter.addEventListener("change", () => {
      const selected = chatDocFilter.value;
      if (selected) {
        if (inputDocPill) inputDocPill.classList.add("has-filter");
        chatInput.placeholder = `Ask a question about ${selected}…`;
      } else {
        if (inputDocPill) inputDocPill.classList.remove("has-filter");
        chatInput.placeholder = "Ask a question, or attach images & files…";
      }
    });
  }

  btnSendChat.addEventListener("click", sendMessage);
  chatInput.addEventListener("keydown", e => { if (e.key === "Enter") sendMessage(); });
  initVoiceToText();

  // ── File Upload ───────────────────────────────────────────────
  btnChooseFile.addEventListener("click", () => fileUploader.click());

  fileUploader.addEventListener("change", async () => {
    if (!fileUploader.files.length) return;
    const form = new FormData();
    for (const f of fileUploader.files) form.append("files", f);
    btnChooseFile.textContent = "Indexing…";
    btnChooseFile.disabled = true;
    try {
      await fetch("/api/documents/upload", { method: "POST", body: form });
      alert("Files indexed successfully.");
      refreshStatus();
      loadDocumentsList();
    } catch { alert("Upload failed."); }
    finally {
      fileUploader.value = "";
      btnChooseFile.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Upload Files`;
      btnChooseFile.disabled = false;
    }
  });

  if (btnLoadSamples) {
    btnLoadSamples.addEventListener("click", async () => {
      btnLoadSamples.textContent = "Indexing…";
      btnLoadSamples.disabled = true;
      try {
        await fetch("/api/documents/load_samples", { method: "POST" });
        alert("Sample dataset indexed.");
        refreshStatus(); loadDocumentsList();
      } catch { alert("Error loading samples."); }
      finally {
        btnLoadSamples.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg> Sample Data`;
        btnLoadSamples.disabled = false;
      }
    });
  }

  btnResetVault.addEventListener("click", async () => {
    if (confirm("Reset workspace? All indexed documents and conversations will be deleted.")) {
      await fetch("/api/workspace/reset", { method: "POST" });
      refreshStatus(); loadConversations(); loadDocumentsList();
    }
  });

  // ── Document Repository ───────────────────────────────────────
  async function loadDocumentsList() {
    try {
      const res = await fetch("/api/documents");
      const data = await res.json();
      const docs = data.documents || {};
      const names = Object.keys(docs);

      // Update chat document selector dropdown
      if (chatDocFilter) {
        const curVal = chatDocFilter.value;
        let optHtml = `<option value="">All Documents</option>`;
        names.forEach(name => {
          optHtml += `<option value="${escHtml(name)}">${escHtml(name)}</option>`;
        });
        chatDocFilter.innerHTML = optHtml;
        if (curVal && names.includes(curVal)) {
          chatDocFilter.value = curVal;
          if (inputDocPill) inputDocPill.classList.add("has-filter");
        } else {
          chatDocFilter.value = "";
          if (inputDocPill) inputDocPill.classList.remove("has-filter");
        }
      }

      // Update sidebar doc list
      if (sidebarDocList) {
        if (names.length === 0) {
          sidebarDocList.innerHTML = "<div style='font-size:0.75rem; color:var(--text-3);'>No documents indexed yet</div>";
        } else {
          sidebarDocList.innerHTML = names.map(n => `
            <div class="sidebar-doc-item" onclick="openDocumentViewer('${encodeURIComponent(n)}')" title="Click to open ${escHtml(n)}">
              <span class="sidebar-doc-name">${escHtml(n)}</span>
              <span class="sidebar-doc-type">${docs[n].source_type}</span>
            </div>`).join("");
        }
      }

      allLoadedDocuments = docs;

      // Update main cards grid
      const q = (repoSearchInput ? repoSearchInput.value : "").trim().toLowerCase();
      const filteredNames = names.filter(n => {
        if (!q) return true;
        const d = docs[n];
        return n.toLowerCase().includes(q) || (d && d.source_type && d.source_type.toLowerCase().includes(q));
      });
      renderDocCards(filteredNames);
      populateActionDocSelectors();
    } catch(e) { console.error(e); }
  }

  function renderDocCards(names) {
    if (!docCardsGrid) return;
    if (!names || names.length === 0) {
      const isFiltered = repoSearchInput && repoSearchInput.value.trim().length > 0;
      docCardsGrid.innerHTML = `
        <div style="grid-column:1/-1; padding:3rem; text-align:center; color:var(--text-3); border:1px dashed var(--border); border-radius:12px;">
          <div style="font-size:2rem; margin-bottom:0.75rem;">📂</div>
          <div style="font-size:0.9rem; font-weight:600; color:var(--text-2); margin-bottom:0.4rem;">
            ${isFiltered ? "No matching documents found" : "Repository is empty"}
          </div>
          <div style="font-size:0.8rem;">
            ${isFiltered ? "Try a different search keyword" : "Upload documents or load the sample enterprise dataset to begin."}
          </div>
        </div>`;
      return;
    }

    docCardsGrid.innerHTML = "";
    names.forEach(name => {
      const d = allLoadedDocuments[name];
      if (!d) return;
      const ext = (name.split('.').pop() || "").toUpperCase();
      const isImg = (d.source_type === "IMAGE") || ["PNG", "JPG", "JPEG", "WEBP", "SVG", "BMP", "GIF"].includes(ext);
      const iconClass = isImg ? "doc-icon-image" : ext === "PDF" ? "doc-icon-pdf" : ext === "DOCX" ? "doc-icon-docx" : "doc-icon-txt";
      const iconEmoji = isImg ? "🖼️" : ext === "PDF" ? "📕" : ext === "DOCX" ? "📘" : (ext === "CSV" ? "📊" : ext === "JSON" ? "📜" : "📄");
      const sizeKb = (d.size_bytes / 1024).toFixed(1);

      const card = document.createElement("div");
      card.className = "doc-card";
      card.innerHTML = `
        <div class="doc-card-header" onclick="openDocumentViewer('${encodeURIComponent(name)}')" title="Click to open ${escHtml(name)}">
          <div class="doc-card-icon ${iconClass}">${iconEmoji}</div>
          <div class="doc-card-meta">
            <div class="doc-card-name" title="${escHtml(name)}">${escHtml(name)}</div>
            <div class="doc-card-sub">${sizeKb} KB · Indexed ${d.indexed_at || ""}</div>
          </div>
        </div>
        <div class="doc-card-stats" onclick="openDocumentViewer('${encodeURIComponent(name)}')">
          <div class="doc-stat"><span class="doc-stat-val">${d.page_count}</span><span class="doc-stat-lbl">${isImg ? "image" : ext === "PDF" ? "pages" : "sections"}</span></div>
          <div class="doc-stat"><span class="doc-stat-val">${d.chunk_count}</span><span class="doc-stat-lbl">passages</span></div>
        </div>
        <div class="doc-card-actions">
          <button class="doc-action-btn primary-doc-btn" onclick="openDocumentViewer('${encodeURIComponent(name)}')">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
            Open Document
          </button>
          <button class="doc-action-btn" onclick="reindexDoc('${encodeURIComponent(name)}')">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
            Re-index
          </button>
          <button class="doc-action-btn danger" onclick="deleteDoc('${encodeURIComponent(name)}')">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg>
            Delete
          </button>
        </div>`;
      docCardsGrid.appendChild(card);
    });
  }

  if (repoSearchInput) {
    repoSearchInput.addEventListener("input", () => {
      const q = repoSearchInput.value.trim().toLowerCase();
      const allNames = Object.keys(allLoadedDocuments);
      const filtered = allNames.filter(n => {
        if (!q) return true;
        const d = allLoadedDocuments[n];
        return n.toLowerCase().includes(q) || (d && d.source_type && d.source_type.toLowerCase().includes(q));
      });
      renderDocCards(filtered);
    });
  }

  window.deleteDoc = async function(enc) {
    const name = decodeURIComponent(enc);
    if (confirm(`Remove "${name}" and all embeddings?`)) {
      await fetch("/api/documents/delete", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filename: name }),
      });
      refreshStatus(); loadDocumentsList();
    }
  };

  window.reindexDoc = async function(enc) {
    const name = decodeURIComponent(enc);
    const res = await fetch("/api/documents/reindex", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: name }),
    });
    const data = await res.json();
    alert(data.message || "Re-indexed.");
    refreshStatus(); loadDocumentsList();
  };

  // ── Document Actions ──────────────────────────────────────────
  function updateActionFormUI() {
    if (!actionTypeSelect) return;
    const actionType = actionTypeSelect.value;
    const labelA = document.getElementById("label-doc-a");
    const labelB = document.getElementById("label-doc-b");

    if (actionType === "tender") {
      if (groupDocB) groupDocB.style.display = "flex";
      if (labelA) labelA.textContent = "Tender / RFP Document";
      if (labelB) labelB.textContent = "Company Baseline & Financials";
      if (btnRunAction) btnRunAction.textContent = "Verify Tender Profitability";
    } else if (actionType === "compare") {
      if (groupDocB) groupDocB.style.display = "flex";
      if (labelA) labelA.textContent = "Document A";
      if (labelB) labelB.textContent = "Document B";
      if (btnRunAction) btnRunAction.textContent = "Run Comparison";
    } else {
      if (groupDocB) groupDocB.style.display = "none";
      if (labelA) labelA.textContent = "Target Document";
      if (btnRunAction) btnRunAction.textContent = "Run Analysis";
    }
  }

  if (actionTypeSelect) {
    actionTypeSelect.addEventListener("change", updateActionFormUI);
  }

  async function populateActionDocSelectors() {
    const res = await fetch("/api/documents");
    const data = await res.json();
    const docs = Object.keys(data.documents || {});

    if (actionDocA) {
      if (docs.length === 0) {
        actionDocA.innerHTML = "<option value=''>No documents indexed</option>";
      } else {
        // Look for tenders first to provide optimal default selection
        const tenderDoc = docs.find(d => d.toLowerCase().includes("tender") || d.toLowerCase().includes("rfp"));
        actionDocA.innerHTML = docs.map(d => {
          const isSelected = tenderDoc ? (d === tenderDoc) : false;
          return `<option value="${escHtml(d)}" ${isSelected ? "selected" : ""}>${escHtml(d)}</option>`;
        }).join("");
      }
    }

    if (actionDocB) {
      if (docs.length === 0) {
        actionDocB.innerHTML = "<option value=''>No documents indexed</option>";
      } else {
        let optHtml = `<option value="__all__" selected>All Company Indexed Files (Holistic)</option>`;
        optHtml += docs.map(d => `<option value="${escHtml(d)}">${escHtml(d)}</option>`).join("");
        actionDocB.innerHTML = optHtml;
      }
    }

    updateActionFormUI();
  }

  if (btnRunAction) {
    btnRunAction.addEventListener("click", async () => {
      const actionType = actionTypeSelect.value;
      const docA = actionDocA.value;
      const docB = actionDocB.value;
      if (!docA) { alert("Select a document first."); return; }
      
      const loadingText = actionType === "tender" ? "Verifying Tender Profitability…" : "Analyzing…";
      btnRunAction.textContent = loadingText;
      btnRunAction.disabled = true;
      actionResultBox.style.display = "none";

      const resultLabel = document.querySelector("#action-result-box .result-label");
      if (resultLabel) {
        resultLabel.textContent = actionType === "tender"
          ? "Tender Profitability & Feasibility Audit"
          : "Analysis Output";
      }

      try {
        const res = await fetch("/api/actions", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action_type: actionType, doc_a: docA, doc_b: docB }),
        });
        const data = await res.json();
        if (data.error) { alert("Error: " + data.error); return; }
        
        actionOutputText.innerHTML = formatAnalysisReport(data.result, actionType);
        
        actionCitationsBox.innerHTML = (data.citations || []).map(c => {
          const score = typeof c.score === "number" ? c.score : 0;
          const isVerified = score >= 80;
          const badgeClass = isVerified ? "badge-verified" : "badge-review";
          const badgeLabel = isVerified ? `Verified • ${score}% Match` : `Needs Review • ${score}% Match`;
          const tierClass = isVerified ? "verified" : "review";
          const excerptSnippet = (c.excerpt || "").substring(0, 200);
          return `
          <div class="citation-card ${tierClass}">
            <div class="citation-header">
              <span>${c.source_tag} — ${escHtml(c.doc_name)} · ${escHtml(c.page_label)}</span>
              <span class="citation-score ${badgeClass}">${badgeLabel}</span>
            </div>
            <div class="citation-excerpt">${escHtml(excerptSnippet)}…</div>
          </div>`;
        }).join("");
        actionResultBox.style.display = "block";
      } catch(e) { alert("Error: " + e); }
      finally { 
        updateActionFormUI();
        btnRunAction.disabled = false; 
      }
    });
  }

  // ── Highlighting & Minimal Report Formatter ───────────────────
  function highlightImportantPhrases(text) {
    if (!text) return "";
    let safe = escHtml(text);

    // 1. Highlight currency amounts ($X,XXX,XXX.XX or with USD/million/etc.)
    safe = safe.replace(/(\$[\d,]+(?:\.\d+)?(?:\s*(?:USD|billion|million|k|M|B))?)/gi, 
      '<span class="hl-tag hl-currency">$1</span>');

    // 2. Highlight percentages (+23.9%, -10.0%, 0%, 99.9%, etc.)
    safe = safe.replace(/([+\-]?\d+(?:\.\d+)?%)/g, function(match, p1) {
      const num = parseFloat(p1);
      const isNeg = p1.startsWith("-") || (num < 0);
      const isPos = p1.startsWith("+") || (num > 0);
      const cls = isNeg ? "hl-pct-neg" : (isPos ? "hl-pct-pos" : "hl-pct-neutral");
      return `<span class="hl-tag ${cls}">${p1}</span>`;
    });

    // 3. Highlight critical liabilities and penalty phrases
    const riskTerms = [
      "Liquidated Damages", "Delay Penalties", "delay penalty", "Penalty Deduction",
      "Bank Guarantee", "forfeiture", "abandonment", "outage", "penalties",
      "liabilities", "non-performance", "uncapped", "DO NOT BID", "UNPROFITABLE",
      "High Risk", "Critical Risk"
    ];
    riskTerms.forEach(term => {
      const reg = new RegExp(`\\b(${term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})\\b`, "gi");
      safe = safe.replace(reg, '<span class="hl-tag hl-risk">$1</span>');
    });

    // 4. Highlight positive / compliance milestones
    const posTerms = [
      "PROFITABLE", "BID RECOMMENDED", "ISO 27001", "SOC 2 Type II", "high-availability",
      "Compliant", "eligibility requirements"
    ];
    posTerms.forEach(term => {
      const reg = new RegExp(`\\b(${term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})\\b`, "gi");
      safe = safe.replace(reg, '<span class="hl-tag hl-success">$1</span>');
    });

    // 5. Highlight caution terms
    const warnTerms = [
      "MARGINAL", "PROCEED WITH CAUTION", "consortium partner", "pricing buffer"
    ];
    warnTerms.forEach(term => {
      const reg = new RegExp(`\\b(${term.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')})\\b`, "gi");
      safe = safe.replace(reg, '<span class="hl-tag hl-warning">$1</span>');
    });

    return safe;
  }

  function formatAnalysisReport(rawText, actionType) {
    if (!rawText) return "<p>No output generated.</p>";

    // If not tender action, provide a clean, readable card layout
    if (actionType !== "tender") {
      const cleanText = rawText.replace(/^[#=_\-*]{2,}\s*/gm, "");
      const lines = cleanText.split("\n");
      let html = `<div class="analysis-report">`;
      let currentSection = "";
      let items = [];

      function flushSection() {
        if (!currentSection && items.length === 0) return;
        html += `<div class="audit-section">`;
        if (currentSection) {
          html += `
          <div class="audit-section-header">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <span class="audit-section-title">${escHtml(currentSection)}</span>
          </div>`;
        }
        html += `<div class="audit-items-list">`;
        items.forEach(it => {
          html += `<p class="audit-para">${highlightImportantPhrases(it)}</p>`;
        });
        html += `</div></div>`;
        items = [];
      }

      lines.forEach(line => {
        const trimmed = line.trim();
        if (!trimmed) return;
        if (trimmed.startsWith("#") || (trimmed.toUpperCase() === trimmed && trimmed.length > 4 && trimmed.length < 50)) {
          flushSection();
          currentSection = trimmed.replace(/^[#\d\.\s]+/, "").trim();
        } else {
          items.push(trimmed.replace(/^[-*•]\s*/, ""));
        }
      });
      flushSection();
      html += `</div>`;
      return html;
    }

    // ── Dedicated Tender Profitability & Feasibility Formatter ───
    const fullUpper = rawText.toUpperCase();
    let verdictType = "marginal";
    let verdictLabel = "MARGINAL — PROCEED WITH CAUTION";
    let verdictIcon = "⚠";

    if (fullUpper.includes("UNPROFITABLE") || fullUpper.includes("DO NOT BID")) {
      verdictType = "unprofitable";
      verdictLabel = "UNPROFITABLE — DO NOT BID";
      verdictIcon = "✕";
    } else if (fullUpper.includes("PROFITABLE") && !fullUpper.includes("MARGINAL")) {
      verdictType = "profitable";
      verdictLabel = "PROFITABLE — BID RECOMMENDED";
      verdictIcon = "✓";
    }

    // Extract Confidence
    let confidence = "Medium";
    const confMatch = rawText.match(/Confidence(?:\s*Rating)?\s*:\s*([A-Za-z]+)/i);
    if (confMatch) confidence = confMatch[1].trim();

    // Extract Executive Justification / Summary
    let summaryText = "";
    const justMatch = rawText.match(/(?:Core Justification|Summary)(?:\*\*)?\s*:\s*([^\n\r]+(?:\n[^\n\r#\-]+)*)/i);
    if (justMatch) {
      summaryText = justMatch[1].replace(/\*\*/g, "").replace(/\n/g, " ").trim();
    } else {
      summaryText = verdictType === "profitable"
        ? "The tender analysis shows favorable commercial margins and technical alignment with existing capabilities."
        : (verdictType === "unprofitable" 
            ? "The tender exhibits severe financial deficits or penalty risks that threaten commercial profitability."
            : "The tender offers notable revenue opportunities but entails high penalty risks or tight delivery margins.");
    }

    // Extract Key KPI Metrics (Ceiling, Cost, Margin)
    let contractCeiling = null;
    let projectedCost = null;
    let netMargin = null;

    const ceilingMatch = rawText.match(/(?:Tender Ceiling|Contract Value)(?:\*\*)?[^\n:]*:\s*([^\n\r]+)/i);
    if (ceilingMatch) {
      const money = ceilingMatch[1].match(/\$[\d,]+(?:\.\d+)?(?:\s*(?:USD|million|M|k))?/i);
      if (money) contractCeiling = money[0].trim();
    }

    const costMatch = rawText.match(/Total Projected Costs?[^\n:]*:\s*([^\n\r]+)/i) ||
                      rawText.match(/(?:Projected Delivery Costs?)[^\n:]*:\s*([^\n\r]+)/i);
    if (costMatch) {
      const money = costMatch[1].match(/\$[\d,]+(?:\.\d+)?(?:\s*(?:USD|million|M|k))?/i);
      if (money) projectedCost = money[0].trim();
    }

    const marginMatch = rawText.match(/(?:Estimated Margin|Margin %|Net Profit & Margin %)(?:\*\*)?[^\n:]*:\s*([^\n\r]+)/i);
    if (marginMatch) {
      const pct = marginMatch[1].match(/[+\-]?\d+(?:\.\d+)?%/);
      if (pct) netMargin = pct[0];
    }
    if (!netMargin) {
      const anyMarginMatch = rawText.match(/Estimated Margin\s*:\s*([^\n\r]+)/i);
      if (anyMarginMatch) {
        const pct = anyMarginMatch[1].match(/[+\-]?\d+(?:\.\d+)?%/);
        if (pct) netMargin = pct[0];
      }
    }

    // Parse Sections & Items
    const sections = [];
    let currentSec = null;

    // Clean text of raw symbols: remove hashes, separators
    const cleanRaw = rawText.replace(/^[=_\-]{3,}\s*$/gm, "");
    const lines = cleanRaw.split("\n");

    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed) return;

      // Skip document title header line if repeated
      if (trimmed.includes("TENDER PROFITABILITY & BID VERIFICATION REPORT") || trimmed.startsWith("Target Tender:")) {
        return;
      }

      // Check if this line is a Section Header
      const headerMatch = trimmed.match(/^(?:#{1,3}\s*|\d+\.\s*)([A-Z0-9\s,&/]{4,60})$/i);
      const isHeader = headerMatch || (trimmed.startsWith("## ") || trimmed.startsWith("### "));

      if (isHeader) {
        let title = trimmed.replace(/^[#\d\.\s]+/, "").trim();
        // Skip verdict section header because verdict is shown in the banner
        if (title.toUpperCase().includes("VERDICT") || title.toUpperCase().includes("BID RECOMMENDATION")) {
          currentSec = null;
          return;
        }
        currentSec = {
          title: title.replace(/^\d+[\.\s]*/, ""),
          rows: [],
          paragraphs: []
        };
        sections.push(currentSec);
        return;
      }

      if (!currentSec) return;

      // Check for bullet row with label: - **Label**: Content or - Label: Content
      const rowMatch = trimmed.match(/^[-*•]\s*(?:\*\*)?([A-Za-z0-9\s,/&%]+?)(?:\*\*)?\s*:\s*(.+)$/);
      if (rowMatch) {
        currentSec.rows.push({
          label: rowMatch[1].trim(),
          content: rowMatch[2].trim(),
          subs: []
        });
      } else if (trimmed.match(/^[-*•]\s*(.+)$/) && currentSec.rows.length > 0) {
        // Nested sub bullet
        const subText = trimmed.replace(/^[-*•]\s*/, "").replace(/\*\*/g, "").trim();
        currentSec.rows[currentSec.rows.length - 1].subs.push(subText);
      } else {
        const cleanPara = trimmed.replace(/^[-*•]\s*/, "").replace(/\*\*/g, "").trim();
        if (cleanPara) {
          currentSec.paragraphs.push(cleanPara);
        }
      }
    });

    // ── Build HTML ───────────────────────────────────────────────
    let html = `<div class="analysis-report">`;

    // 1. Liquid Glass Top Verdict Banner
    html += `
    <div class="verdict-card ${verdictType}">
      <div class="verdict-header">
        <div class="verdict-badge-wrap">
          <div class="verdict-icon-pill">${verdictIcon}</div>
          <div class="verdict-title">${verdictLabel}</div>
        </div>
        <div class="verdict-conf-pill">${escHtml(confidence)} Confidence</div>
      </div>
      <p class="verdict-summary">${highlightImportantPhrases(summaryText)}</p>
    </div>`;

    // 2. Executive Financial Highlights Strip (if metrics detected)
    if (contractCeiling || projectedCost || netMargin) {
      let marginClass = "kpi-amber";
      if (netMargin) {
        const val = parseFloat(netMargin);
        if (val > 0) marginClass = "kpi-green";
        else if (val < 0) marginClass = "kpi-red";
      }

      html += `
      <div class="kpi-metrics-grid">
        <div class="kpi-card">
          <span class="kpi-label">Contract Ceiling</span>
          <span class="kpi-value">${escHtml(contractCeiling || "Evaluated")}</span>
          <span class="kpi-sub">Total ceiling cited in tender</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-label">Projected Delivery Cost</span>
          <span class="kpi-value">${escHtml(projectedCost || "Calculated")}</span>
          <span class="kpi-sub">Labor, materials & execution</span>
        </div>
        <div class="kpi-card">
          <span class="kpi-label">Projected Margin</span>
          <span class="kpi-value ${marginClass}">${escHtml(netMargin || "Evaluated")}</span>
          <span class="kpi-sub">Net commercial profitability</span>
        </div>
      </div>`;
    }

    // 3. Structured Section Cards
    sections.forEach(sec => {
      if (sec.rows.length === 0 && sec.paragraphs.length === 0) return;

      html += `
      <div class="audit-section">
        <div class="audit-section-header">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
          <span class="audit-section-title">${escHtml(sec.title)}</span>
        </div>
        <div class="audit-items-list">`;

      sec.rows.forEach(r => {
        html += `
        <div class="audit-row">
          <div class="audit-row-label">${escHtml(r.label)}</div>
          <div class="audit-row-content">${highlightImportantPhrases(r.content)}</div>`;

        if (r.subs && r.subs.length > 0) {
          html += `<div class="audit-sub-chips">`;
          r.subs.forEach(s => {
            html += `<div class="audit-sub-chip">${highlightImportantPhrases(s)}</div>`;
          });
          html += `</div>`;
        }

        html += `</div>`;
      });

      sec.paragraphs.forEach(p => {
        html += `<p class="audit-para">${highlightImportantPhrases(p)}</p>`;
      });

      html += `</div></div>`;
    });

    html += `</div>`;
    return html;
  }

  // ── Settings ──────────────────────────────────────────────────
  if (btnSaveSettings) {
    btnSaveSettings.addEventListener("click", async () => {
      await fetch("/api/config", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          endpoint: settingEndpoint.value.trim(),
          chat_model: settingChatModel.value.trim(),
          embed_model: settingEmbedModel.value.trim(),
        }),
      });
      await refreshStatus();
      btnSaveSettings.textContent = "Saved ✓";
      setTimeout(() => { btnSaveSettings.textContent = "Save Settings"; }, 1800);
    });
  }

  // ── Universal Document Viewer ──────────────────────────────────
  let viewerState = {
    docName: "",
    currentPage: 1,
    pageCount: 1,
    data: null,
    viewMode: "scan",
    highlight: "",
  };

  window.openDocumentViewer = async function(enc, page = 1, highlight = "") {
    const name = decodeURIComponent(enc);
    viewerState.docName = name;
    viewerState.currentPage = parseInt(page) || 1;
    viewerState.highlight = highlight || "";

    pdfModal.classList.add("active");
    if (docViewerLoader) docViewerLoader.style.display = "flex";
    if (docVisualContainer) docVisualContainer.style.display = "none";
    if (docTextContainer) docTextContainer.style.display = "none";

    modalTitle.textContent = name;
    if (docViewerMeta) docViewerMeta.textContent = "Loading document content...";
    if (btnDownloadDoc) {
      btnDownloadDoc.href = `/api/documents/raw?doc_name=${encodeURIComponent(name)}&download=1`;
    }

    try {
      const res = await fetch(`/api/documents/content?doc_name=${encodeURIComponent(name)}&page_num=${viewerState.currentPage}`);
      const data = await res.json();
      if (!data.success) {
        alert("Error loading document: " + (data.error || "Unknown error"));
        if (docViewerLoader) docViewerLoader.style.display = "none";
        return;
      }

      viewerState.data = data;
      viewerState.pageCount = data.page_count || 1;
      viewerState.currentPage = data.current_page || 1;

      // Update badge & meta
      if (docViewerIcon) {
        docViewerIcon.textContent = data.source_type || (data.extension ? data.extension.toUpperCase() : "DOC");
      }
      if (docViewerMeta) {
        const sizeKb = data.size_bytes ? (data.size_bytes / 1024).toFixed(1) + " KB" : "";
        const pagesText = data.page_count > 1 ? `${data.page_count} Pages` : (data.source_type === "DOCX" ? `${data.page_count} Sections` : "1 Page");
        docViewerMeta.textContent = [pagesText, sizeKb].filter(Boolean).join(" · ");
      }

      // Decide view mode
      if (data.has_visual_scan) {
        viewerState.viewMode = "scan";
        if (docViewModeGroup) docViewModeGroup.style.display = "inline-flex";
        if (btnViewScan) btnViewScan.classList.add("active");
        if (btnViewText) btnViewText.classList.remove("active");
      } else {
        viewerState.viewMode = "text";
        if (docViewModeGroup) docViewModeGroup.style.display = "none";
      }

      // Update Page Nav
      updateViewerPageNav();

      // Render content
      renderViewerCurrentMode();

    } catch (e) {
      console.error(e);
      alert("Failed to fetch document content: " + e.message);
    } finally {
      if (docViewerLoader) docViewerLoader.style.display = "none";
    }
  };

  function updateViewerPageNav() {
    if (!docPageNav) return;
    if (viewerState.pageCount > 1) {
      docPageNav.style.display = "inline-flex";
      if (docPageIndicator) {
        docPageIndicator.textContent = `Page ${viewerState.currentPage} / ${viewerState.pageCount}`;
      }
      if (btnPrevPage) btnPrevPage.disabled = (viewerState.currentPage <= 1);
      if (btnNextPage) btnNextPage.disabled = (viewerState.currentPage >= viewerState.pageCount);
    } else {
      docPageNav.style.display = "none";
    }
  }

  function renderViewerCurrentMode() {
    const data = viewerState.data;
    if (!data) return;

    if (viewerState.viewMode === "scan" && data.has_visual_scan) {
      if (docVisualContainer) docVisualContainer.style.display = "block";
      if (docTextContainer) docTextContainer.style.display = "none";
      let url = `/api/documents/preview?doc_name=${encodeURIComponent(viewerState.docName)}&page_num=${viewerState.currentPage}`;
      if (viewerState.highlight) {
        url += `&highlight=${encodeURIComponent(viewerState.highlight)}`;
      }
      modalImg.src = url;
    } else {
      // Text view
      if (docVisualContainer) docVisualContainer.style.display = "none";
      if (docTextContainer) docTextContainer.style.display = "block";

      if (data.source_type === "CSV" && data.table_rows && data.table_rows.length > 0) {
        const headerRow = data.table_rows[0];
        const bodyRows = data.table_rows.slice(1);
        let tableHtml = `<div style="overflow-x:auto;"><table class="doc-table-view"><thead><tr>`;
        headerRow.forEach(h => { tableHtml += `<th>${escHtml(h)}</th>`; });
        tableHtml += `</tr></thead><tbody>`;
        bodyRows.forEach(row => {
          tableHtml += `<tr>`;
          row.forEach(cell => { tableHtml += `<td>${escHtml(cell)}</td>`; });
          tableHtml += `</tr>`;
        });
        tableHtml += `</tbody></table></div>`;
        docTextContent.innerHTML = tableHtml;
        docTextContent.className = "doc-text-content";
      } else if (data.source_type === "JSON") {
        docTextContent.innerHTML = `<pre class="doc-text-content mono"><code>${escHtml(data.full_text || data.page_text || "")}</code></pre>`;
      } else if (data.sections && data.sections.length > 0) {
        let secHtml = "";
        data.sections.forEach(s => {
          secHtml += `<div class="doc-text-section-header">${escHtml(s.page_label || "Section")}</div>`;
          secHtml += `<div style="margin-bottom:16px;">${escHtml(s.text || "").replace(/\n/g, "<br>")}</div>`;
        });
        docTextContent.innerHTML = secHtml;
        docTextContent.className = "doc-text-content";
      } else {
        const textToDisplay = data.page_text || data.full_text || "No text available.";
        docTextContent.textContent = textToDisplay;
        docTextContent.className = "doc-text-content";
      }
    }
  }

  // Hook view mode switcher
  if (btnViewScan) {
    btnViewScan.addEventListener("click", () => {
      viewerState.viewMode = "scan";
      btnViewScan.classList.add("active");
      if (btnViewText) btnViewText.classList.remove("active");
      renderViewerCurrentMode();
    });
  }
  if (btnViewText) {
    btnViewText.addEventListener("click", () => {
      viewerState.viewMode = "text";
      btnViewText.classList.add("active");
      if (btnViewScan) btnViewScan.classList.remove("active");
      renderViewerCurrentMode();
    });
  }

  // Hook Prev/Next Page
  if (btnPrevPage) {
    btnPrevPage.addEventListener("click", async () => {
      if (viewerState.currentPage > 1) {
        await window.openDocumentViewer(encodeURIComponent(viewerState.docName), viewerState.currentPage - 1, viewerState.highlight);
      }
    });
  }
  if (btnNextPage) {
    btnNextPage.addEventListener("click", async () => {
      if (viewerState.currentPage < viewerState.pageCount) {
        await window.openDocumentViewer(encodeURIComponent(viewerState.docName), viewerState.currentPage + 1, viewerState.highlight);
      }
    });
  }

  // Hook Copy Text
  if (btnCopyDocText) {
    btnCopyDocText.addEventListener("click", () => {
      const data = viewerState.data;
      const text = data ? (data.full_text || data.page_text || "") : "";
      if (text) {
        navigator.clipboard.writeText(text).then(() => {
          const original = btnCopyDocText.innerHTML;
          btnCopyDocText.innerHTML = `<span>Copied ✓</span>`;
          setTimeout(() => { btnCopyDocText.innerHTML = original; }, 1800);
        });
      }
    });
  }

  // Backward compatible alias
  window.openPdfPreview = function(enc, page, highlight = "") {
    window.openDocumentViewer(enc, page, highlight);
  };
  btnCloseModal.addEventListener("click", () => pdfModal.classList.remove("active"));
  pdfModal.addEventListener("click", e => { if (e.target === pdfModal) pdfModal.classList.remove("active"); });

  // ── HTML escape ───────────────────────────────────────────────
  function escHtml(s) {
    if (!s) return "";
    return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  // ── Authentication Management ─────────────────────────────────
  function getInitials(name) {
    if (!name) return "U";
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  function setAuthAlert(msg, type = "error") {
    if (!authAlert) return;
    if (!msg) {
      authAlert.style.display = "none";
      authAlert.textContent = "";
      return;
    }
    authAlert.className = `auth-alert ${type}`;
    authAlert.textContent = msg;
    authAlert.style.display = "block";
  }

  function updateAuthUI(user) {
    if (user) {
      const inits = getInitials(user.display_name || user.username);
      if (railUserAvatar) railUserAvatar.textContent = inits;
      if (userAvatarSm) userAvatarSm.textContent = inits;
      if (userNameDisplay) userNameDisplay.textContent = user.display_name || user.username;
      if (userRoleDisplay) userRoleDisplay.textContent = `@${user.username} · Local User`;

      if (accValDisplay) accValDisplay.textContent = user.display_name || user.username;
      if (accValUsername) accValUsername.textContent = user.username;
      if (accValEmail) accValEmail.textContent = user.email || "Not specified";
      if (accValCreated) accValCreated.textContent = user.created_at || "—";
      if (accValLastLogin) accValLastLogin.textContent = user.last_login || "Just now";
      if (accCardSub) accCardSub.textContent = `Logged in as @${user.username}`;
      if (accStatusTag) {
        accStatusTag.textContent = "Authenticated";
        accStatusTag.style.color = "#22c55e";
        accStatusTag.style.borderColor = "rgba(34, 197, 94, 0.3)";
      }

      // Hide auth modal overlay
      if (authModal) authModal.classList.remove("active");
    } else {
      if (railUserAvatar) railUserAvatar.textContent = "?";
      if (userAvatarSm) userAvatarSm.textContent = "?";
      if (userNameDisplay) userNameDisplay.textContent = "Guest";
      if (userRoleDisplay) userRoleDisplay.textContent = "Not signed in";

      if (accValDisplay) accValDisplay.textContent = "—";
      if (accValUsername) accValUsername.textContent = "—";
      if (accValEmail) accValEmail.textContent = "—";
      if (accValCreated) accValCreated.textContent = "—";
      if (accValLastLogin) accValLastLogin.textContent = "—";
      if (accCardSub) accCardSub.textContent = "No active session";
      if (accStatusTag) {
        accStatusTag.textContent = "Signed Out";
        accStatusTag.style.color = "#f59e0b";
        accStatusTag.style.borderColor = "rgba(245, 158, 11, 0.3)";
      }

      // Open auth modal overlay
      if (authModal) authModal.classList.add("active");
    }
  }

  async function checkAuth() {
    try {
      const res = await fetch("/api/auth/me");
      const data = await res.json();
      if (data.authenticated && data.user) {
        currentUser = data.user;
        updateAuthUI(currentUser);
      } else {
        currentUser = null;
        updateAuthUI(null);
      }
    } catch (e) {
      console.warn("Auth check failed:", e);
      currentUser = null;
      updateAuthUI(null);
    }
  }

  // Auth Tab Switchers
  if (tabBtnLogin && tabBtnRegister) {
    tabBtnLogin.addEventListener("click", () => {
      tabBtnLogin.classList.add("active");
      tabBtnRegister.classList.remove("active");
      if (formLogin) formLogin.classList.add("active");
      if (formRegister) formRegister.classList.remove("active");
      setAuthAlert(null);
    });

    tabBtnRegister.addEventListener("click", () => {
      tabBtnRegister.classList.add("active");
      tabBtnLogin.classList.remove("active");
      if (formRegister) formRegister.classList.add("active");
      if (formLogin) formLogin.classList.remove("active");
      setAuthAlert(null);
    });
  }

  // Show/Hide password toggle
  document.querySelectorAll(".btn-toggle-pwd").forEach(btn => {
    btn.addEventListener("click", () => {
      const targetId = btn.getAttribute("data-target");
      const input = document.getElementById(targetId);
      if (input) {
        if (input.type === "password") {
          input.type = "text";
          btn.style.color = "var(--accent-hi)";
        } else {
          input.type = "password";
          btn.style.color = "var(--text-3)";
        }
      }
    });
  });

  // Handle Login Submit
  if (formLogin) {
    formLogin.addEventListener("submit", async e => {
      e.preventDefault();
      setAuthAlert(null);
      const username = loginUsername.value.trim();
      const password = loginPassword.value;

      if (!username || !password) {
        setAuthAlert("Please enter both username and password.", "error");
        return;
      }

      btnSubmitLogin.disabled = true;
      const originalText = btnSubmitLogin.innerHTML;
      btnSubmitLogin.innerHTML = `<span>Signing in…</span>`;

      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, password })
        });
        const data = await res.json();

        if (res.ok && data.success) {
          currentUser = data.user;
          setAuthAlert("Signed in successfully!", "success");
          setTimeout(() => {
            updateAuthUI(currentUser);
            loginPassword.value = "";
            setAuthAlert(null);
            loadConversations();
            loadDocumentsList();
          }, 350);
        } else {
          setAuthAlert(data.message || "Invalid credentials. Please try again.", "error");
        }
      } catch (err) {
        setAuthAlert("Network error connecting to local server.", "error");
      } finally {
        btnSubmitLogin.disabled = false;
        btnSubmitLogin.innerHTML = originalText;
      }
    });
  }

  // Handle Register Submit
  if (formRegister) {
    formRegister.addEventListener("submit", async e => {
      e.preventDefault();
      setAuthAlert(null);
      const displayName = regName.value.trim();
      const username = regUsername.value.trim();
      const email = regEmail.value.trim();
      const password = regPassword.value;

      if (!username || !password) {
        setAuthAlert("Username and password are required.", "error");
        return;
      }

      btnSubmitRegister.disabled = true;
      const originalText = btnSubmitRegister.innerHTML;
      btnSubmitRegister.innerHTML = `<span>Creating account…</span>`;

      try {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            username,
            password,
            display_name: displayName,
            email
          })
        });
        const data = await res.json();

        if (res.ok && data.success) {
          currentUser = data.user;
          setAuthAlert("Account created successfully! Welcome to VaultAI.", "success");
          setTimeout(() => {
            updateAuthUI(currentUser);
            regPassword.value = "";
            setAuthAlert(null);
            loadConversations();
            loadDocumentsList();
          }, 450);
        } else {
          setAuthAlert(data.message || "Registration failed. Try a different username.", "error");
        }
      } catch (err) {
        setAuthAlert("Network error during registration.", "error");
      } finally {
        btnSubmitRegister.disabled = false;
        btnSubmitRegister.innerHTML = originalText;
      }
    });
  }

  // Handle Logout
  async function performLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch (e) {
      console.warn("Logout error:", e);
    }
    currentUser = null;
    updateAuthUI(null);
    if (tabBtnLogin) tabBtnLogin.click();
    setAuthAlert("You have been signed out.", "success");
  }

  if (btnUserLogout) {
    btnUserLogout.addEventListener("click", e => {
      e.stopPropagation();
      performLogout();
    });
  }

  if (btnSettingsLogout) {
    btnSettingsLogout.addEventListener("click", () => {
      performLogout();
    });
  }

  if (btnSettingsSwitch) {
    btnSettingsSwitch.addEventListener("click", () => {
      if (authModal) {
        authModal.classList.add("active");
        if (tabBtnLogin) tabBtnLogin.click();
        setAuthAlert("Sign in with another account or create a new one.", "success");
      }
    });
  }

  if (btnRailUser) {
    btnRailUser.addEventListener("click", () => {
      navigateTo("tab-settings");
    });
  }

  // ── Boot ──────────────────────────────────────────────────────
  checkAuth();
  refreshStatus();
  loadConversations();
  loadDocumentsList();
  // Poll status every 30s
  setInterval(refreshStatus, 30000);

});

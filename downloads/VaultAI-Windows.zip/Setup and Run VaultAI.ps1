$ErrorActionPreference = 'Stop'
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollama) {
    if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Write-Host 'Install Ollama from https://ollama.com/download/windows, then run this launcher again.'; exit 1 }
    winget install --id Ollama.Ollama --exact --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    $env:PATH += ";$env:LOCALAPPDATA\Programs\Ollama"
    $ollama = Get-Command ollama -ErrorAction SilentlyContinue
}
if (-not $ollama) { Write-Host 'Restart Windows after installing Ollama, then run this launcher again.'; exit 1 }
foreach ($model in @('qwen2.5:3b', 'nomic-embed-text')) {
    & $ollama.Source pull $model
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

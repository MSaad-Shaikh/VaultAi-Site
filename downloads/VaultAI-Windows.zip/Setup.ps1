winget install --id Ollama.Ollama --exact --accept-source-agreements --accept-package-agreements
